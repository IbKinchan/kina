/*
[+] =============================================== [+]
[+]                                                            [+]
[+] - INSTALLER PTERODACTYL                              [+]
[+]                                                            [+]
[+]  TQTO :                                                   [+]
[+] • WannOffc ( MySelf)                                     [+]
[+] • Creator Bot WhatsApp & Telegram                     [+]
[+] • Para Pengguna Bot Tele & Wa                         [+]
[+]                                                            [+]
[+] © CreateByWannFyy                                      [+]
[+] =============================================== [+]
*/

const config = {
  token: '6598615685:AAGP4iddabUnL91wgpTpJPVbU91czJsJpcY',
  adminId: '7171688438', 
};

module.exports = config;