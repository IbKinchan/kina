/*
[+] =============================================== [+]
[+]                                                            [+]
[+] - INSTALLER PTERODACTYL                              [+]
[+]                                                            [+]
[+]  TQTO :                                                   [+]
[+] • WannOffc ( MySelf)                                     [+]
[+] • Creator Bot WhatsApp & Telegram                     [+]
[+] • Para Pengguna Bot Tele & Wa                         [+]
[+]                                                            [+]
[+] © CreateByWannFyy                                      [+]
[+] =============================================== [+]
*/

const config = {
  token: 'TOKEN_BOT',
  adminId: 'ID_OWNER', 
};

module.exports = config;